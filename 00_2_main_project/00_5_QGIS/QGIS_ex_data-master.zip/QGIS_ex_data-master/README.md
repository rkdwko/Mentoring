# 본 자료는 다음 youtube QGIS 강좌에서 이용됩니다.

## https://www.youtube.com/watch?v=5Y5rqEfMF38&list=PLidue65j7H2ofZCclyD79O-b3zTcG6wRR


